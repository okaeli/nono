---
id: 24_project_solar_system
title: 24_project_solar_system
---

![Thirty Days Of JavaScript](../static/img/images/banners/day_1_24.png)

- [Day 24](#day-24)
  - [Exercises](#exercises)
    - [Exercise: Level 1](#exercise-level-1)

# Day 24

## Exercises

### Exercise: Level 1

1. Develop a small application which calculate a weight of an object in a certain planet. The gif image is not complete check the video in the starter file.

![Solar System](../static/img/images/projects/dom_min_project_solar_system_day_4.1.gif)

🎉 CONGRATULATIONS ! 🎉
