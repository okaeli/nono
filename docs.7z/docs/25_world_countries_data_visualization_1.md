---
id: 25_world_countries_data_visualization_1
title: 25_world_countries_data_visualization_1
---

![Thirty Days Of JavaScript](../static/img/images/banners/day_1_25.png)

- [Day 25](#day-25)
  - [Exercises](#exercises)
    - [Exercise: Level 1](#exercise-level-1)

# Day 25

## Exercises

### Exercise: Level 1

1. Visualize the ten most populated countries and the ten most spoken languages in the world using DOM(HTML, CSS, JS)

![Bar Graph](../static/img/images/projects/dom_min_project_bar_graph_day_5.1.gif)

![Bar Graph](../static/img/images/projects/dom_min_project_bar_graph_day_5.1.png)

🎉 CONGRATULATIONS ! 🎉