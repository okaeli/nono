---
id: 26_world_countries_data_visualization_2
title: 26_world_countries_data_visualization_2
---

![Thirty Days Of JavaScript](../static/img/images/banners/day_1_26.png)

- [Day 26](#day-26)
  - [Exercises](#exercises)
    - [Exercise: Level 1](#exercise-level-1)

# Day 26

## Exercises

### Exercise: Level 1

1. Visualize the countries array as follows

![Motivation](../static/img/images/projects/dom_mini_project_countries_day_6.1.gif)

🎉 CONGRATULATIONS ! 🎉
