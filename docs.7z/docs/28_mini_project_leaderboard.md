---
id: 28_mini_project_leaderboard
title: 28_mini_project_leaderboard
---

![Thirty Days Of JavaScript](../static/img/images/banners/day_1_28.png)

- [Day 28](#day-28)
  - [Exercises](#exercises)
    - [Exercise: Level 1](#exercise-level-1)

# Day 28

## Exercises

### Exercise: Level 1

1. Create the following using HTML, CSS, and JavaScript

![Slider](../static/img/images/projects/dom_mini_project_leaderboard_day_8.1.gif)

🎉 CONGRATULATIONS ! 🎉