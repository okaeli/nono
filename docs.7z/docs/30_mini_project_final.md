---
id: 30_mini_project_final
title: 30_mini_project_final
---

![Thirty Days Of JavaScript](../static/img/images/banners/day_1_30.png)

- [Day 30](#day-30)
  - [Exercises](#exercises)
    - [Exercise: Level 1](#exercise-level-1)
    - [Exercise: Level 2](#exercise-level-2)
    - [Exercise: Level 3](#exercise-level-3)

# Day 30

## Exercises

### Exercise: Level 1

1. Create the following animation using (HTML, CSS, JS)

![Countries daata](../static/img/images/projects/dom_mini_project_countries_object_day_10.1.gif)

2. Validate the following form using regex.

   ![form validation](../static/img/images/projects/dom_mini_project_form_validation_day_10.2.1.png)
   
   ![form validation](../static/img/images/projects/dom_mini_project_form_validation_day_10.2.png)


### Exercise: Level 2

### Exercise: Level 3

🌕 Your journey to greatness completed successfully. You reached high level of greatness. Now, you are much greater than ever before. I knew what it takes to reach to this level and you made to this point. You are a real hero. Now, it is time to celebrate your success with a friend or with a family. I am looking forward to seeing you in an other challenge.

~![Congratulations](../static/img/images/projects/congratulations.gif)
