---
id: 27_mini_project_portfolio
title: 27_mini_project_portfolio
---

![Thirty Days Of JavaScript](../static/img/images/banners/day_1_27.png)

- [Day 27](#day-27)
  - [Exercises](#exercises)
    - [Exercise: Level 1](#exercise-level-1)

# Day 27

## Exercises

### Exercise: Level 1

1. Create the following using HTML, CSS, and JavaScript

![Slider](../static/img/images/projects/dom_mini_project_slider_day_7.1.gif)

🎉 CONGRATULATIONS ! 🎉