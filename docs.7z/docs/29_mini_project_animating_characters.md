---
id: 29_mini_project_animating_characters
title: 29_mini_project_animating_characters
---

![Thirty Days Of JavaScript](../static/img/images/banners/day_1_29.png)

- [Day 29](#day-29)
  - [Exercises](#exercises)
    - [Exercise: Level 1](#exercise-level-1)
    - [Exercise: Level 2](#exercise-level-2)
    - [Exercise: Level 3](#exercise-level-3)

# Day 29

## Exercises

### Exercise: Level 1

1. Create the following animation using (HTML, CSS, JS)

![Slider](../static/img/images/projects/dom_min_project_30DaysOfJavaScript_color_changing_day_9.1.gif)


### Exercise: Level 2

### Exercise: Level 3

🎉 CONGRATULATIONS ! 🎉